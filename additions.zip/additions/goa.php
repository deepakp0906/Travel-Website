<?php
    header("Content-Type: text/xml");
    $feed = file_get_contents("goa.xml");
    echo $feed;
?>
