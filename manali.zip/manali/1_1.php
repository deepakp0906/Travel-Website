<html>
<head>
<style>
body {
  background-image: url('man1.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
</style>
 <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
<script>
function getVote(int) {
  if (window.XMLHttpRequest) {
    xmlhttp=new XMLHttpRequest();
  } else {  // 
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
      document.getElementById("poll").innerHTML=this.responseText;
    }
  }
  xmlhttp.open("GET","poll_vote.php?vote="+int,true);
  xmlhttp.send();
}
function myFunction() {
  var txt=document.getElementById("fname").value;
  var btn = document.createElement("h5");
  btn.innerHTML = txt;
  document.body.appendChild(btn);
}
</script>
</head>
<body>
<?php
$filename = "poll_result.txt";
$content = file($filename);

//put content in array
$array = explode("||", $content[0]);
$yes = $array[0];
$no = $array[1];
?>
<h2>Result:</h2>
<table>
<tr>
<td>Yes:</td>
</tr>
</table>
<div class="progress" style="width:30%">
    <div class="progress-bar bg-success" style="width:<?php echo(100*round($yes/($no+$yes),2)); ?>%">
      <span class="sr-only">70% Complete</span>
    </div>
  </div>
</div>
<table>
<tr>
<td>No:</td>
</tr>
</table>
<div class="progress" style="width:30%">
    <div class="progress-bar bg-danger" style="width:<?php echo(100*round($no/($no+$yes),2)); ?>%">
      <span class="sr-only">70% Complete</span>
    </div>
  </div>
</div>
<div id="poll">
<h3>Did you enjoy your stay at the hotel?</h3>
<form>
Yes:
<input type="radio" name="vote" value="0" onclick="getVote(this.value)">
<br>No:
<input type="radio" name="vote" value="1" onclick="getVote(this.value)">
</form>
</div>

  <h2>Write A Review</h2>
<input type="text" id="fname" name="fname"><br><br>
<input type="submit" value="Submit" onclick="myFunction()">
<br/>
<br/>
<div class="container" id="reviews"></div>
</body>
</html>